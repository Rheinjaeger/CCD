/*
 * net_if.h
 *
 *  Created on: Nov 16, 2025
 *      Author: Shrek
 */

#ifndef INC_NET_IF_H_
#define INC_NET_IF_H_

#pragma once
#include "wizchip_conf.h"

void NET_Init(void);

#endif /* INC_NET_IF_H_ */
